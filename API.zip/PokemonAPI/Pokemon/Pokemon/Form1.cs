﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PokeAPI;
using System.Windows.Forms;

namespace Pokemon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public async void GeneratePokemon()
        {
            int i = int.Parse(IdText.Text);
            if (i > 0 && i < 899)
            {
                PokemonSpecies p = await DataFetcher.GetApiObject<PokemonSpecies>(i);
                NameOutput.Text = p.Name;
                HappinessOutput.Text = p.BaseHappiness.ToString();
                EggOutput.Text = p.EggGroup[0].Name;
                CaptureOutput.Text = p.CaptureRate.ToString();
                GrowthOutput.Text = p.GrowthRate.Name;
                HabitatOutput.Text = p.Habitat.Name;
                FlavorOutput.Text = p.FlavorTexts[8].FlavorText;
            }
        }
        private void Generate_Click(object sender, EventArgs e)
        {
            GeneratePokemon();
        }

    }
}
