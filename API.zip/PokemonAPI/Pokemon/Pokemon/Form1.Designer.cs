﻿
namespace Pokemon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Generate = new System.Windows.Forms.Button();
            this.Instructions = new System.Windows.Forms.Label();
            this.IdText = new System.Windows.Forms.TextBox();
            this.Name = new System.Windows.Forms.Label();
            this.NameOutput = new System.Windows.Forms.Label();
            this.Happiness = new System.Windows.Forms.Label();
            this.HappinessOutput = new System.Windows.Forms.Label();
            this.Egg = new System.Windows.Forms.Label();
            this.EggOutput = new System.Windows.Forms.Label();
            this.Capture = new System.Windows.Forms.Label();
            this.CaptureOutput = new System.Windows.Forms.Label();
            this.Growth = new System.Windows.Forms.Label();
            this.GrowthOutput = new System.Windows.Forms.Label();
            this.Habitat = new System.Windows.Forms.Label();
            this.HabitatOutput = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.FlavorOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Generate
            // 
            this.Generate.Location = new System.Drawing.Point(54, 25);
            this.Generate.Name = "Generate";
            this.Generate.Size = new System.Drawing.Size(132, 23);
            this.Generate.TabIndex = 0;
            this.Generate.Text = "Generate Pokemon";
            this.Generate.UseVisualStyleBackColor = true;
            this.Generate.Click += new System.EventHandler(this.Generate_Click);
            // 
            // Instructions
            // 
            this.Instructions.AutoSize = true;
            this.Instructions.Location = new System.Drawing.Point(0, 9);
            this.Instructions.Name = "Instructions";
            this.Instructions.Size = new System.Drawing.Size(107, 13);
            this.Instructions.TabIndex = 1;
            this.Instructions.Text = "Enter Pokemon ID #:";
            // 
            // IdText
            // 
            this.IdText.Location = new System.Drawing.Point(113, 2);
            this.IdText.Name = "IdText";
            this.IdText.Size = new System.Drawing.Size(100, 20);
            this.IdText.TabIndex = 0;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(0, 80);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(86, 13);
            this.Name.TabIndex = 2;
            this.Name.Text = "Pokemon Name:";
            // 
            // NameOutput
            // 
            this.NameOutput.AutoSize = true;
            this.NameOutput.Location = new System.Drawing.Point(92, 80);
            this.NameOutput.Name = "NameOutput";
            this.NameOutput.Size = new System.Drawing.Size(0, 13);
            this.NameOutput.TabIndex = 3;
            // 
            // Happiness
            // 
            this.Happiness.AutoSize = true;
            this.Happiness.Location = new System.Drawing.Point(0, 110);
            this.Happiness.Name = "Happiness";
            this.Happiness.Size = new System.Drawing.Size(87, 13);
            this.Happiness.TabIndex = 4;
            this.Happiness.Text = "Base Happiness:";
            // 
            // HappinessOutput
            // 
            this.HappinessOutput.AutoSize = true;
            this.HappinessOutput.Location = new System.Drawing.Point(98, 109);
            this.HappinessOutput.Name = "HappinessOutput";
            this.HappinessOutput.Size = new System.Drawing.Size(0, 13);
            this.HappinessOutput.TabIndex = 5;
            // 
            // Egg
            // 
            this.Egg.AutoSize = true;
            this.Egg.Location = new System.Drawing.Point(0, 140);
            this.Egg.Name = "Egg";
            this.Egg.Size = new System.Drawing.Size(61, 13);
            this.Egg.TabIndex = 6;
            this.Egg.Text = "Egg Group:";
            // 
            // EggOutput
            // 
            this.EggOutput.AutoSize = true;
            this.EggOutput.Location = new System.Drawing.Point(69, 140);
            this.EggOutput.Name = "EggOutput";
            this.EggOutput.Size = new System.Drawing.Size(0, 13);
            this.EggOutput.TabIndex = 7;
            // 
            // Capture
            // 
            this.Capture.AutoSize = true;
            this.Capture.Location = new System.Drawing.Point(0, 168);
            this.Capture.Name = "Capture";
            this.Capture.Size = new System.Drawing.Size(73, 13);
            this.Capture.TabIndex = 8;
            this.Capture.Text = "Capture Rate:";
            // 
            // CaptureOutput
            // 
            this.CaptureOutput.AutoSize = true;
            this.CaptureOutput.Location = new System.Drawing.Point(79, 168);
            this.CaptureOutput.Name = "CaptureOutput";
            this.CaptureOutput.Size = new System.Drawing.Size(0, 13);
            this.CaptureOutput.TabIndex = 9;
            // 
            // Growth
            // 
            this.Growth.AutoSize = true;
            this.Growth.Location = new System.Drawing.Point(0, 192);
            this.Growth.Name = "Growth";
            this.Growth.Size = new System.Drawing.Size(70, 13);
            this.Growth.TabIndex = 10;
            this.Growth.Text = "Growth Rate:";
            // 
            // GrowthOutput
            // 
            this.GrowthOutput.AutoSize = true;
            this.GrowthOutput.Location = new System.Drawing.Point(69, 192);
            this.GrowthOutput.Name = "GrowthOutput";
            this.GrowthOutput.Size = new System.Drawing.Size(0, 13);
            this.GrowthOutput.TabIndex = 11;
            // 
            // Habitat
            // 
            this.Habitat.AutoSize = true;
            this.Habitat.Location = new System.Drawing.Point(3, 218);
            this.Habitat.Name = "Habitat";
            this.Habitat.Size = new System.Drawing.Size(44, 13);
            this.Habitat.TabIndex = 12;
            this.Habitat.Text = "Habitat:";
            // 
            // HabitatOutput
            // 
            this.HabitatOutput.AutoSize = true;
            this.HabitatOutput.Location = new System.Drawing.Point(57, 218);
            this.HabitatOutput.Name = "HabitatOutput";
            this.HabitatOutput.Size = new System.Drawing.Size(0, 13);
            this.HabitatOutput.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Flavor Text:";
            // 
            // FlavorOutput
            // 
            this.FlavorOutput.AutoSize = true;
            this.FlavorOutput.Location = new System.Drawing.Point(69, 245);
            this.FlavorOutput.Name = "FlavorOutput";
            this.FlavorOutput.Size = new System.Drawing.Size(0, 13);
            this.FlavorOutput.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FlavorOutput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HabitatOutput);
            this.Controls.Add(this.Habitat);
            this.Controls.Add(this.GrowthOutput);
            this.Controls.Add(this.Growth);
            this.Controls.Add(this.CaptureOutput);
            this.Controls.Add(this.Capture);
            this.Controls.Add(this.EggOutput);
            this.Controls.Add(this.Egg);
            this.Controls.Add(this.HappinessOutput);
            this.Controls.Add(this.Happiness);
            this.Controls.Add(this.NameOutput);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.IdText);
            this.Controls.Add(this.Instructions);
            this.Controls.Add(this.Generate);
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Generate;
        private System.Windows.Forms.Label Instructions;
        private System.Windows.Forms.TextBox IdText;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label NameOutput;
        private System.Windows.Forms.Label Happiness;
        private System.Windows.Forms.Label HappinessOutput;
        private System.Windows.Forms.Label Egg;
        private System.Windows.Forms.Label EggOutput;
        private System.Windows.Forms.Label Capture;
        private System.Windows.Forms.Label CaptureOutput;
        private System.Windows.Forms.Label Growth;
        private System.Windows.Forms.Label GrowthOutput;
        private System.Windows.Forms.Label Habitat;
        private System.Windows.Forms.Label HabitatOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label FlavorOutput;
    }
}

