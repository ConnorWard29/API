﻿using System;
using Star_Wars_API.Objects;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Star_Wars_API
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private async void planetGenerator_Click(object sender, EventArgs e)
        {
            string a = planetInput.Text;
            Planet p = await JSONHelper.GetPlanet(a);
            planetNameOutput.Text = p.name;
            pRPo.Text = p.rotation_period;
            pOPo.Text = p.orbital_period;
            pDo.Text = p.diameter;
            pCo.Text = p.climate;
            pGo.Text = p.gravity;
            pTo.Text = p.terrain;
            pSWo.Text = p.surface_water;
            pPo.Text = p.population;
        }
        private async void characterGenerator_Click_1(object sender, EventArgs e)
        {
            string b = characterInput.Text;
            Character c = await JSONHelper.GetCharacter(b);
            cNo.Text = c.name;
            cHo.Text = c.height;
            cMo.Text = c.mass;
            cHCo.Text = c.hair_color;
            cSCo.Text = c.skin_color;
            cECo.Text = c.eye_color;
            cBYo.Text = c.birth_year;
            cGo.Text = c.gender;
            cHWo.Text = c.homeworld;

        }

        private async void speciesGenerator_Click(object sender, EventArgs e)
        {
            string d = characterInput.Text;
            Speice s = await JSONHelper.GetSpeice(d);
            sCo.Text = s.classification;
            sDo.Text = s.designation;
            sAHo.Text = s.average_height;
            sSCo.Text = s.skin_colors;
            sHCo.Text = s.hair_colors;
            sECo.Text = s.eye_colors;
            sALo.Text = s.average_lifespan;
            sHWo.Text = s.homeworld;
            sLo.Text = s.language;
        }
    }
}
