﻿using System;
using Newtonsoft.Json;
using Star_Wars_API.Objects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;

namespace Star_Wars_API
{
    class JSONHelper
    {

        static readonly HttpClient client = new HttpClient();

        public static async Task<Planet> GetPlanet(string a)
        {
            Planet generatedPlanet = new Planet();
            string lp = "https://swapi.dev/api/planets/" + a + "/";
            try
            {
                HttpResponseMessage response = await client.GetAsync(lp);
                response.EnsureSuccessStatusCode();
                string responseBodyP = await response.Content.ReadAsStringAsync();

                generatedPlanet = JsonConvert.DeserializeObject<Planet>(responseBodyP);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return generatedPlanet;
        }

        public static async Task<Character> GetCharacter(string b)
        {
            Character generatedCharacter = new Character();
            string lc = "https://swapi.dev/api/people/" + b + "/";
            try
            {
                HttpResponseMessage response = await client.GetAsync(lc);
                response.EnsureSuccessStatusCode();
                string responseBodyC = await response.Content.ReadAsStringAsync();

                generatedCharacter = JsonConvert.DeserializeObject<Character>(responseBodyC);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return generatedCharacter;
        }

        public static async Task<Speice> GetSpeice(string c)
        {
            Speice generatedSpeice = new Speice();
            string ls = "https://swapi.dev/api/species/" + c + "/";
            try
            {
                HttpResponseMessage response = await client.GetAsync(ls);
                response.EnsureSuccessStatusCode();
                string responseBodyC = await response.Content.ReadAsStringAsync();

                generatedSpeice = JsonConvert.DeserializeObject<Speice>(responseBodyC);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return generatedSpeice;
        }
    }
}
