﻿
namespace Star_Wars_API
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pInstruction = new System.Windows.Forms.Label();
            this.planetInput = new System.Windows.Forms.TextBox();
            this.speciesInput = new System.Windows.Forms.TextBox();
            this.characterInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.planetGenerator = new System.Windows.Forms.Button();
            this.speciesGenerator = new System.Windows.Forms.Button();
            this.characterGenerator = new System.Windows.Forms.Button();
            this.planetName = new System.Windows.Forms.Label();
            this.planetNameOutput = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.characterNameOutput = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pDo = new System.Windows.Forms.Label();
            this.pRPo = new System.Windows.Forms.Label();
            this.pOPo = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pCo = new System.Windows.Forms.Label();
            this.pGo = new System.Windows.Forms.Label();
            this.pTo = new System.Windows.Forms.Label();
            this.pSWo = new System.Windows.Forms.Label();
            this.pPo = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cNo = new System.Windows.Forms.Label();
            this.cHo = new System.Windows.Forms.Label();
            this.cMo = new System.Windows.Forms.Label();
            this.cHCo = new System.Windows.Forms.Label();
            this.cSCo = new System.Windows.Forms.Label();
            this.cECo = new System.Windows.Forms.Label();
            this.cBYo = new System.Windows.Forms.Label();
            this.cGo = new System.Windows.Forms.Label();
            this.cHWo = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.sLo = new System.Windows.Forms.Label();
            this.sHWo = new System.Windows.Forms.Label();
            this.sALo = new System.Windows.Forms.Label();
            this.sECo = new System.Windows.Forms.Label();
            this.sHCo = new System.Windows.Forms.Label();
            this.sSCo = new System.Windows.Forms.Label();
            this.sAHo = new System.Windows.Forms.Label();
            this.sDo = new System.Windows.Forms.Label();
            this.sCo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pInstruction
            // 
            this.pInstruction.AutoSize = true;
            this.pInstruction.Location = new System.Drawing.Point(12, 9);
            this.pInstruction.Name = "pInstruction";
            this.pInstruction.Size = new System.Drawing.Size(82, 13);
            this.pInstruction.TabIndex = 0;
            this.pInstruction.Text = "Enter Planet ID:";
            // 
            // planetInput
            // 
            this.planetInput.Location = new System.Drawing.Point(100, 6);
            this.planetInput.Name = "planetInput";
            this.planetInput.Size = new System.Drawing.Size(47, 20);
            this.planetInput.TabIndex = 1;
            // 
            // speciesInput
            // 
            this.speciesInput.Location = new System.Drawing.Point(574, 6);
            this.speciesInput.Name = "speciesInput";
            this.speciesInput.Size = new System.Drawing.Size(47, 20);
            this.speciesInput.TabIndex = 2;
            // 
            // characterInput
            // 
            this.characterInput.Location = new System.Drawing.Point(393, 6);
            this.characterInput.Name = "characterInput";
            this.characterInput.Size = new System.Drawing.Size(47, 20);
            this.characterInput.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(478, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Species ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(289, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Enter Character ID:";
            // 
            // planetGenerator
            // 
            this.planetGenerator.Location = new System.Drawing.Point(15, 32);
            this.planetGenerator.Name = "planetGenerator";
            this.planetGenerator.Size = new System.Drawing.Size(132, 23);
            this.planetGenerator.TabIndex = 6;
            this.planetGenerator.Text = "Generate Planet";
            this.planetGenerator.UseVisualStyleBackColor = true;
            this.planetGenerator.Click += new System.EventHandler(this.planetGenerator_Click);
            // 
            // speciesGenerator
            // 
            this.speciesGenerator.Location = new System.Drawing.Point(481, 32);
            this.speciesGenerator.Name = "speciesGenerator";
            this.speciesGenerator.Size = new System.Drawing.Size(140, 23);
            this.speciesGenerator.TabIndex = 7;
            this.speciesGenerator.Text = "Generate Species";
            this.speciesGenerator.UseVisualStyleBackColor = true;
            this.speciesGenerator.Click += new System.EventHandler(this.speciesGenerator_Click);
            // 
            // characterGenerator
            // 
            this.characterGenerator.Location = new System.Drawing.Point(292, 32);
            this.characterGenerator.Name = "characterGenerator";
            this.characterGenerator.Size = new System.Drawing.Size(148, 23);
            this.characterGenerator.TabIndex = 8;
            this.characterGenerator.Text = "Generate Character";
            this.characterGenerator.UseVisualStyleBackColor = true;
            this.characterGenerator.Click += new System.EventHandler(this.characterGenerator_Click_1);
            // 
            // planetName
            // 
            this.planetName.AutoSize = true;
            this.planetName.Location = new System.Drawing.Point(12, 73);
            this.planetName.Name = "planetName";
            this.planetName.Size = new System.Drawing.Size(38, 13);
            this.planetName.TabIndex = 9;
            this.planetName.Text = "Name:";
            // 
            // planetNameOutput
            // 
            this.planetNameOutput.AutoSize = true;
            this.planetNameOutput.Location = new System.Drawing.Point(56, 73);
            this.planetNameOutput.Name = "planetNameOutput";
            this.planetNameOutput.Size = new System.Drawing.Size(0, 13);
            this.planetNameOutput.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(283, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Name:";
            // 
            // characterNameOutput
            // 
            this.characterNameOutput.AutoSize = true;
            this.characterNameOutput.Location = new System.Drawing.Point(390, 191);
            this.characterNameOutput.Name = "characterNameOutput";
            this.characterNameOutput.Size = new System.Drawing.Size(0, 13);
            this.characterNameOutput.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Rotation Period:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Orbital Period:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Diameter:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 238);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Climate:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 283);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Gravity:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 320);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Terrain:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 362);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Surface Water:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 403);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Population:";
            // 
            // pDo
            // 
            this.pDo.AutoSize = true;
            this.pDo.Location = new System.Drawing.Point(70, 191);
            this.pDo.Name = "pDo";
            this.pDo.Size = new System.Drawing.Size(0, 13);
            this.pDo.TabIndex = 21;
            // 
            // pRPo
            // 
            this.pRPo.AutoSize = true;
            this.pRPo.Location = new System.Drawing.Point(97, 113);
            this.pRPo.Name = "pRPo";
            this.pRPo.Size = new System.Drawing.Size(0, 13);
            this.pRPo.TabIndex = 22;
            // 
            // pOPo
            // 
            this.pOPo.AutoSize = true;
            this.pOPo.Location = new System.Drawing.Point(91, 150);
            this.pOPo.Name = "pOPo";
            this.pOPo.Size = new System.Drawing.Size(0, 13);
            this.pOPo.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(283, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 13);
            this.label12.TabIndex = 24;
            // 
            // pCo
            // 
            this.pCo.AutoSize = true;
            this.pCo.Location = new System.Drawing.Point(56, 238);
            this.pCo.Name = "pCo";
            this.pCo.Size = new System.Drawing.Size(0, 13);
            this.pCo.TabIndex = 25;
            // 
            // pGo
            // 
            this.pGo.AutoSize = true;
            this.pGo.Location = new System.Drawing.Point(61, 283);
            this.pGo.Name = "pGo";
            this.pGo.Size = new System.Drawing.Size(0, 13);
            this.pGo.TabIndex = 26;
            // 
            // pTo
            // 
            this.pTo.AutoSize = true;
            this.pTo.Location = new System.Drawing.Point(61, 320);
            this.pTo.Name = "pTo";
            this.pTo.Size = new System.Drawing.Size(0, 13);
            this.pTo.TabIndex = 27;
            // 
            // pSWo
            // 
            this.pSWo.AutoSize = true;
            this.pSWo.Location = new System.Drawing.Point(97, 362);
            this.pSWo.Name = "pSWo";
            this.pSWo.Size = new System.Drawing.Size(0, 13);
            this.pSWo.TabIndex = 28;
            // 
            // pPo
            // 
            this.pPo.AutoSize = true;
            this.pPo.Location = new System.Drawing.Point(78, 403);
            this.pPo.Name = "pPo";
            this.pPo.Size = new System.Drawing.Size(0, 13);
            this.pPo.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(280, 113);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 30;
            this.label13.Text = "Height:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(280, 150);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 31;
            this.label14.Text = "Mass:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(280, 191);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "Hair Color:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(278, 238);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 33;
            this.label16.Text = "Skin Color:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(280, 283);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 13);
            this.label17.TabIndex = 34;
            this.label17.Text = "Eye Color:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(278, 320);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 13);
            this.label18.TabIndex = 35;
            this.label18.Text = "Birth Year:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(280, 362);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 13);
            this.label19.TabIndex = 36;
            this.label19.Text = "Gender:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(252, 403);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 13);
            this.label20.TabIndex = 37;
            this.label20.Text = "Homeworld:";
            // 
            // cNo
            // 
            this.cNo.AutoSize = true;
            this.cNo.Location = new System.Drawing.Point(327, 73);
            this.cNo.Name = "cNo";
            this.cNo.Size = new System.Drawing.Size(0, 13);
            this.cNo.TabIndex = 38;
            // 
            // cHo
            // 
            this.cHo.AutoSize = true;
            this.cHo.Location = new System.Drawing.Point(327, 113);
            this.cHo.Name = "cHo";
            this.cHo.Size = new System.Drawing.Size(0, 13);
            this.cHo.TabIndex = 39;
            // 
            // cMo
            // 
            this.cMo.AutoSize = true;
            this.cMo.Location = new System.Drawing.Point(321, 150);
            this.cMo.Name = "cMo";
            this.cMo.Size = new System.Drawing.Size(0, 13);
            this.cMo.TabIndex = 40;
            // 
            // cHCo
            // 
            this.cHCo.AutoSize = true;
            this.cHCo.Location = new System.Drawing.Point(342, 191);
            this.cHCo.Name = "cHCo";
            this.cHCo.Size = new System.Drawing.Size(0, 13);
            this.cHCo.TabIndex = 41;
            // 
            // cSCo
            // 
            this.cSCo.AutoSize = true;
            this.cSCo.Location = new System.Drawing.Point(342, 238);
            this.cSCo.Name = "cSCo";
            this.cSCo.Size = new System.Drawing.Size(0, 13);
            this.cSCo.TabIndex = 42;
            // 
            // cECo
            // 
            this.cECo.AutoSize = true;
            this.cECo.Location = new System.Drawing.Point(341, 283);
            this.cECo.Name = "cECo";
            this.cECo.Size = new System.Drawing.Size(0, 13);
            this.cECo.TabIndex = 43;
            // 
            // cBYo
            // 
            this.cBYo.AutoSize = true;
            this.cBYo.Location = new System.Drawing.Point(340, 320);
            this.cBYo.Name = "cBYo";
            this.cBYo.Size = new System.Drawing.Size(0, 13);
            this.cBYo.TabIndex = 44;
            // 
            // cGo
            // 
            this.cGo.AutoSize = true;
            this.cGo.Location = new System.Drawing.Point(331, 362);
            this.cGo.Name = "cGo";
            this.cGo.Size = new System.Drawing.Size(0, 13);
            this.cGo.TabIndex = 45;
            // 
            // cHWo
            // 
            this.cHWo.AutoSize = true;
            this.cHWo.Location = new System.Drawing.Point(321, 403);
            this.cHWo.Name = "cHWo";
            this.cHWo.Size = new System.Drawing.Size(0, 13);
            this.cHWo.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(478, 73);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 13);
            this.label21.TabIndex = 47;
            this.label21.Text = "Classification:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(478, 113);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 13);
            this.label22.TabIndex = 48;
            this.label22.Text = "Designation:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(478, 150);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(84, 13);
            this.label23.TabIndex = 49;
            this.label23.Text = "Average Height:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(478, 191);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(63, 13);
            this.label24.TabIndex = 50;
            this.label24.Text = "Skin Colors:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(478, 238);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(61, 13);
            this.label25.TabIndex = 51;
            this.label25.Text = "Hair Colors:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(478, 283);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 13);
            this.label26.TabIndex = 52;
            this.label26.Text = "Eye Colors:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(478, 320);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(93, 13);
            this.label27.TabIndex = 53;
            this.label27.Text = "Average Lifespan:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(478, 362);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(63, 13);
            this.label28.TabIndex = 54;
            this.label28.Text = "Homeworld:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(478, 403);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 13);
            this.label29.TabIndex = 55;
            this.label29.Text = "Language:";
            // 
            // sLo
            // 
            this.sLo.AutoSize = true;
            this.sLo.Location = new System.Drawing.Point(542, 403);
            this.sLo.Name = "sLo";
            this.sLo.Size = new System.Drawing.Size(0, 13);
            this.sLo.TabIndex = 56;
            // 
            // sHWo
            // 
            this.sHWo.AutoSize = true;
            this.sHWo.Location = new System.Drawing.Point(547, 362);
            this.sHWo.Name = "sHWo";
            this.sHWo.Size = new System.Drawing.Size(0, 13);
            this.sHWo.TabIndex = 57;
            // 
            // sALo
            // 
            this.sALo.AutoSize = true;
            this.sALo.Location = new System.Drawing.Point(577, 320);
            this.sALo.Name = "sALo";
            this.sALo.Size = new System.Drawing.Size(0, 13);
            this.sALo.TabIndex = 58;
            // 
            // sECo
            // 
            this.sECo.AutoSize = true;
            this.sECo.Location = new System.Drawing.Point(542, 283);
            this.sECo.Name = "sECo";
            this.sECo.Size = new System.Drawing.Size(0, 13);
            this.sECo.TabIndex = 59;
            // 
            // sHCo
            // 
            this.sHCo.AutoSize = true;
            this.sHCo.Location = new System.Drawing.Point(542, 238);
            this.sHCo.Name = "sHCo";
            this.sHCo.Size = new System.Drawing.Size(0, 13);
            this.sHCo.TabIndex = 60;
            // 
            // sSCo
            // 
            this.sSCo.AutoSize = true;
            this.sSCo.Location = new System.Drawing.Point(542, 191);
            this.sSCo.Name = "sSCo";
            this.sSCo.Size = new System.Drawing.Size(0, 13);
            this.sSCo.TabIndex = 61;
            // 
            // sAHo
            // 
            this.sAHo.AutoSize = true;
            this.sAHo.Location = new System.Drawing.Point(568, 150);
            this.sAHo.Name = "sAHo";
            this.sAHo.Size = new System.Drawing.Size(0, 13);
            this.sAHo.TabIndex = 62;
            // 
            // sDo
            // 
            this.sDo.AutoSize = true;
            this.sDo.Location = new System.Drawing.Point(550, 113);
            this.sDo.Name = "sDo";
            this.sDo.Size = new System.Drawing.Size(0, 13);
            this.sDo.TabIndex = 63;
            // 
            // sCo
            // 
            this.sCo.AutoSize = true;
            this.sCo.Location = new System.Drawing.Point(555, 73);
            this.sCo.Name = "sCo";
            this.sCo.Size = new System.Drawing.Size(0, 13);
            this.sCo.TabIndex = 64;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.sCo);
            this.Controls.Add(this.sDo);
            this.Controls.Add(this.sAHo);
            this.Controls.Add(this.sSCo);
            this.Controls.Add(this.sHCo);
            this.Controls.Add(this.sECo);
            this.Controls.Add(this.sALo);
            this.Controls.Add(this.sHWo);
            this.Controls.Add(this.sLo);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.cHWo);
            this.Controls.Add(this.cGo);
            this.Controls.Add(this.cBYo);
            this.Controls.Add(this.cECo);
            this.Controls.Add(this.cSCo);
            this.Controls.Add(this.cHCo);
            this.Controls.Add(this.cMo);
            this.Controls.Add(this.cHo);
            this.Controls.Add(this.cNo);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pPo);
            this.Controls.Add(this.pSWo);
            this.Controls.Add(this.pTo);
            this.Controls.Add(this.pGo);
            this.Controls.Add(this.pCo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pOPo);
            this.Controls.Add(this.pRPo);
            this.Controls.Add(this.pDo);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.characterNameOutput);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.planetNameOutput);
            this.Controls.Add(this.planetName);
            this.Controls.Add(this.characterGenerator);
            this.Controls.Add(this.speciesGenerator);
            this.Controls.Add(this.planetGenerator);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.characterInput);
            this.Controls.Add(this.speciesInput);
            this.Controls.Add(this.planetInput);
            this.Controls.Add(this.pInstruction);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pInstruction;
        private System.Windows.Forms.TextBox planetInput;
        private System.Windows.Forms.TextBox speciesInput;
        private System.Windows.Forms.TextBox characterInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button planetGenerator;
        private System.Windows.Forms.Button speciesGenerator;
        private System.Windows.Forms.Button characterGenerator;
        private System.Windows.Forms.Label planetName;
        private System.Windows.Forms.Label planetNameOutput;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label characterNameOutput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pDo;
        private System.Windows.Forms.Label pRPo;
        private System.Windows.Forms.Label pOPo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label pCo;
        private System.Windows.Forms.Label pGo;
        private System.Windows.Forms.Label pTo;
        private System.Windows.Forms.Label pSWo;
        private System.Windows.Forms.Label pPo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label cNo;
        private System.Windows.Forms.Label cHo;
        private System.Windows.Forms.Label cMo;
        private System.Windows.Forms.Label cHCo;
        private System.Windows.Forms.Label cSCo;
        private System.Windows.Forms.Label cECo;
        private System.Windows.Forms.Label cBYo;
        private System.Windows.Forms.Label cGo;
        private System.Windows.Forms.Label cHWo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label sLo;
        private System.Windows.Forms.Label sHWo;
        private System.Windows.Forms.Label sALo;
        private System.Windows.Forms.Label sECo;
        private System.Windows.Forms.Label sHCo;
        private System.Windows.Forms.Label sSCo;
        private System.Windows.Forms.Label sAHo;
        private System.Windows.Forms.Label sDo;
        private System.Windows.Forms.Label sCo;
    }
}

